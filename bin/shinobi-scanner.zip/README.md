# Shinobi Scanner

Use `./shinobi -a [ADDRESS]` for scan all ports and `-p [PORTS]` parameter for specific ports

![](img/scan.png)

![](img/scan-port.png)
